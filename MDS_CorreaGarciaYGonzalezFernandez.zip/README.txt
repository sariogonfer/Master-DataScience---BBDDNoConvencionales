En primer lugar, es necesario tener levantada una instancia de MongoDB levantada en local.

En nuestro caso, hemos hecho uso de una base de datos MongoDB encapsulada en un contenedor docker. Es
posible realizarlo mediante una instalaci�n nativa sobre linux pero hemos preferido la otra opci�n. Si se desea utilizar
el mismo contenedor que hemos utilizado en nuestro caso, basta con ejecutar el siguiente comando:

sudo docker run --name practica-bbdd-mongo -d -p 27017:27017 mongo

Una vez lanzado el comando indicado, para volver a arrancar el contenedor basta con ejecutar el comando start
con el nombre del contenedor creado:

sudo docker start practica-bbdd-mongo

##########################################################################################################################

Para parsear los datos del fichero dblp.xml, basta con ejecutar el script adjunto parse.sh:

./parse.sh

Esta ejecuci�n, a trav�s de ciertas librer�as de spark, generar� unos ficheros de salida. En el anexo B se explica el paso a paso
del script.

##########################################################################################################################

Para la importaci�n a MongoDB, basta con ejecutar, una vez hemos generado los ficheros mediante el script de parseo, los siguientes comandos:

mongoimport --db=dblp --collection=articles json/articles.json
mongoimport --db=dblp --collection=incollections json/incollections.json
mongoimport --db=dblp --collection=inproceedings json/inproceedings.json

##########################################################################################################################

Por otro lado, para importar los ficheros en csv generados por el parseador, basta con ejecutar el siguiente comando:

neo4j-admin import -nodes:Publication "publications.header.csv,publications/part.*" -nodes:Author "authors.header.csv,authors/part.*" -relationships:Writed "rels.header.csv,rels/part.*" --ignore-duplicate-nodes=true


##########################################################################################################################

Para m�s detalles, consultar la memoria


